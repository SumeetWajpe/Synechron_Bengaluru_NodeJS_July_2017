﻿var fs = require('fs');

var readableStream = fs.createReadStream('Dta.txt');
readableStream.setEncoding('UTF8');
readableStream.on('data', function (chunk) {
    console.log('data : ' + chunk);
});

readableStream.on('end', function (chunk) {
    console.log('end ');
});

readableStream.on('error', function (err) {
    console.log('Error : ' + err);
});