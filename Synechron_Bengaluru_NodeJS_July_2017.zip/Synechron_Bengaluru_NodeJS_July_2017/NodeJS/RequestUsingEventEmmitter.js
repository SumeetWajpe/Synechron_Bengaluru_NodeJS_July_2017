﻿var request = require('request');
var ee = request('http://www.google.com');// returns an instance of EventEmitter!

ee.on('data', function (chunk) {
    console.log('\n\n\n >>>>>>>>>>>>>>>>>>>>>>> Data >>>>>>>>>>>>>> \n\n\n' + chunk)
});

ee.on('end', function () {
    console.log('>>> DONE >>>>>');
});