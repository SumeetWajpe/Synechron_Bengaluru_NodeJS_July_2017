﻿var socket = require('socket.io');
var fs = require('fs');
const http = require('http');
const hostname = '127.0.0.1';
const port = 3000;
//const server = http.createServer(function(req, res){
//    res.statusCode = 200;
//res.setHeader('Content-Type', 'text/html');
//res.end('<h1>Hello World</h1>');
//});
const server = http.createServer(function(req, res){
    fs.readFile(__dirname + "/Client.html",function(err,dataFromFile){
        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/html');
        res.end(dataFromFile);
    });     
});
server.listen(port, hostname, () => {
     console.log(`Server running at http://${hostname}:${port}/`); // ES 6
  //  console.log('Server running at http://' + hostname + ":" + port )
});

var io = socket.listen(server);

io.sockets.on('connection',function(skt){
    setInterval(function () {
        var dataToBeSent = new Date();
        skt.emit('messageForClient',dataToBeSent);    
    },2000);

    skt.on('messagetoServer',function(dataFromClient){
        console.log('Data From Client : ' + dataFromClient);
    });

});


