﻿var EventEmitter = require('events').EventEmitter;
function getResource(noOfIterations) { // return an EventEmitter instance
        var e = new EventEmitter();
    // emit the events
    process.nextTick(function () {
        var cnt = 0;
        e.emit('start');
        var t = setInterval(function () {
            e.emit('item', ++cnt);// emit the item
            if (cnt == noOfIterations) {
                e.emit('finish', cnt);
                clearInterval(t);
            }
        }, 1000);
    });
    return e;
}

// Client

var emt = getResource(5);

emt.on('item', function (theCount) {
    console.log(theCount);
});

emt.on('start', function () {
    console.log('I Have started iteration !');
});

emt.on('finish', function (theCount) {
    console.log('I have ended with the final count : ' + theCount);
});

