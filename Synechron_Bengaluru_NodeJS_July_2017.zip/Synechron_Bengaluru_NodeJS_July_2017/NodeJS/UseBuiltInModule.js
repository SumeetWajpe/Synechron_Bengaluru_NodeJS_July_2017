﻿var fs = require('fs'); // built - in

fs.readFile('Data.txt', function (err, dataFromTheFile) {
    if (err) {
        console.log('Error : ' + err)
    }
    else {
        console.log('Reading Result (Async) : ' + dataFromTheFile);
    }
})