﻿var count = 10;
var PI = 3.14;

module.exports.Pie = PI;
module.exports.Addition = function (x,y) {
    return x + y;
}

