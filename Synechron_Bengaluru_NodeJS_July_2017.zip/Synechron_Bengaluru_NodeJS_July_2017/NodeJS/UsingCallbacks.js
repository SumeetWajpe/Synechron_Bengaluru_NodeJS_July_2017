﻿var processResult = function (err, results) {
    if (err) {
        console.log('Error : ' + err.message)
    }
    else {
        console.log('The result is : ' + results);
    }
}

var Multiplier = function (theNo,callBackFunc) {
    if (theNo % 2 == 0) {
        setTimeout(function () {
            // Multiply the number
            callBackFunc(null, theNo * 2);
        },200);
    }
    else {
        setTimeout(function () {
            // Now its an error !
            callBackFunc(new Error('The input is Odd !'));
        },100);
    }
}

Multiplier(2, processResult);
Multiplier(5, processResult);
Multiplier(1, processResult);
console.log('--------------------------------------');