﻿var net = require('net');
var fs = require('fs');

var server = net.createServer(function (connect) {
    console.log('Connection Established !');
    var log = fs.createWriteStream('Logs.txt');
    connect.on('end', function () {
        console.log('Connection ended !');
    });
    connect.write('Some Default messages here.. \r\n')
    connect.on('data', function (chunk) {
        console.log(chunk.toString());
        if (chunk.toString() == '\r\n') {
            connect.pipe(connect).pipe(log);
        }
    })
});
server.listen(6565, function () {
    console.log('Server listening at 6565 !');
})