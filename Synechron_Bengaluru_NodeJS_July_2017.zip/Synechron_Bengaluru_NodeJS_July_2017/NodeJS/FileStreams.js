﻿var fs = require('fs');

var readeableStream = fs.createReadStream('Data.txt');
var writableStream = fs.createWriteStream('Output.txt');


readeableStream.setEncoding('UTF8');

readeableStream.pipe(writableStream);

//var allData = '';

//readeableStream.on('data', function (chunk) {
//    allData += chunk;
//});

//readeableStream.on('end', function () {
//    writableStream.write(allData);
//    writableStream.end();
//});

