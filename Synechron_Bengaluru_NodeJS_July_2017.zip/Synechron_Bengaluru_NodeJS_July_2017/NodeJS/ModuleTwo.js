﻿var modOne = require('./ModuleOne');

console.log(modOne.Pie);
console.log(modOne.Addition(20,30));
console.log(modOne.count);
