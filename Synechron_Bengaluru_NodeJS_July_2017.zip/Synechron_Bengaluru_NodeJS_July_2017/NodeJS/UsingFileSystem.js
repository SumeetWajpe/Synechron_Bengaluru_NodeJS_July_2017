﻿var fs = require('fs');

/* Sync */
/*
if (fs.existsSync('temp')) {
    console.log('Directory exists.. Removing..');
    if (fs.existsSync('temp/newTest.txt')) {
        fs.unlinkSync('temp/newTest.txt'); // unlinking the file and the folder (deleting the file)
    }
    fs.rmdirSync('temp'); // deleting the dir ! (empty)
}

fs.mkdirSync('temp');

if (fs.existsSync('temp')) {
    process.chdir('temp');
    fs.writeFileSync('test.txt', 'This is some sample data to be written !');
    fs.renameSync('test.txt', 'newTest.txt');
    console.log('File has a size of : ' + fs.statSync('newTest.txt').size + " bytes !");
    console.log('File Contents : ' + fs.readFileSync('newTest.txt').toString());
}

console.log('Program Ended !');
*/


fs.mkdir('temp', function (err) {
    console.log('Within Make Dir !');
    if (err) {
        console.log('Error : ' + err)
    }
    else {
        fs.exists('temp', function (exists) {
            if (exists) {
                process.chdir('temp');
                fs.writeFile('test.txt', 'This is some sample data to be written(async) !', function (err) {
                    fs.rename('test.txt', 'newTest.txt', function (err) {
                        console.log('Renaming..');
                        fs.stat('newTest.txt', function (err, stats) {
                            console.log('File has a size of : ' + stats.size + " bytes !");
                            fs.readFile('newTest.txt', function (err, data) {
                                console.log('File Contents: ' + data);
                            })
                        });
                    });
                });
            }
        });
    }
});

console.log('Program Ended !');
