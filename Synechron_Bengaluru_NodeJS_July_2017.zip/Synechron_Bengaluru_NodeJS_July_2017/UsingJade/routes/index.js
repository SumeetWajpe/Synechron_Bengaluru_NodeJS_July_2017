﻿var express = require('express');

var router = express.Router();

router.get('/', function (req, res) {
    res.render('home',
        {
            title: 'Using Jade',
            message: 'This is displayed using Jade Engine !'
        });
});

router.get('/products', function (req, res) {
    res.render('products',
        {
            title:'Using Jade!',
            products:['TV','Mobile','Camera']
        });
});

module.exports = router;