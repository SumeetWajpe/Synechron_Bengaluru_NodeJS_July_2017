var x = 100;
var booleanVar = false;
var stringVar = "Hello Gulp";

/* This is a Calculator and this comment would not appear in the minified version ! */

function Addition(aVeryLargeX,aVeryLargeY) {
    return aVeryLargeX + aVeryLargeY;
}