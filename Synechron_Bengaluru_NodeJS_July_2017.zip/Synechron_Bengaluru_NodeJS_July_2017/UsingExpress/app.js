﻿var express = require('express');
var app = express();
var router = express.Router();
var bodyParser = require('body-parser');

//router.route('/Products').get(function (req,res) {
//    var products = [
//        { Name: 'Laptop', Price: 40000 },
//        { Name: 'Mobile', Price: 10000 },
//        { Name: 'TV', Price: 20000 }
//    ];
//    res.json(products);
//});

//router.route('/Products/:name').get(function (req,res) {
//    var pName = req.params.name;
//    res.end('U requested for ' + pName);
//});

router.route('/Products/:from-:to').get(function (req,res) {
    var products = [
        { Name: 'Laptop', Price: 40000 },
        { Name: 'Mobile', Price: 10000 },
        { Name: 'TV', Price: 20000 }
    ];  
    var fromRange = parseInt(req.params.from);
    var toRange = parseInt(req.params.to);
    res.json(products.slice(fromRange,toRange));
});
app.use('/api', router);  // http://localhost:4000/api/Products

app.use(bodyParser.urlencoded({ extended : false }));

app.get('/', function (req, res) {
    //res.send('<h1> Hello Express ! </h1>');
    res.sendFile('Client.html', { root: __dirname }); 
});

app.post('/login', function (req, res) {    
   console.log("Welcome" +  req.body.username);
    res.send("success");
})

// handle error 404 !
app.use(function (req, res) {
    res.writeHead(404);
    res.end('Resource not found !');
});

app.listen(4000, function () {
    console.log('Server running @4000 ! ');
});
