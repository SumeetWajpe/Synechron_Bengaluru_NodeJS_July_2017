﻿var multiply = require('./Multiply');

module.exports = function (x) {
    return multiply(x, x);
}