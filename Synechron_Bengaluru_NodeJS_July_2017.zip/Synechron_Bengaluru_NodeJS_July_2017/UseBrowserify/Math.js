﻿var square = require('./Square');

console.log(square(125));