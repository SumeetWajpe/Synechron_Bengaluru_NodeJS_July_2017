﻿module.exports = function (x, y) {
    return x * y;
}